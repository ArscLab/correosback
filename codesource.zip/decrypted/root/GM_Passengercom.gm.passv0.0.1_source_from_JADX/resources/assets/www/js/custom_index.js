//Idioma
lg = get_ls("ls_applg");
//alert(lg);

function go_m1() {
	location.assign(lg + "_main.html?se=" + ix);
}

function go_m2() {
	location.assign(lg + "_notificaciones.html?se=" + ix);
}

function go_m3() {
	location.assign(lg + "_reservFuturas.html?se=" + ix);
}

function go_m4() {
	location.assign(lg + "_tarjetaEmployee.html?se=" + ix);
}

function go_m5(part) {
	location.assign(lg + "_viajes_activos.html?se=" + ix);
}

function go_m6(part) {
	location.assign(lg + "_ubicaciones.html?se=" + ix);
}

function go_m7(part) {
	location.assign(lg + "_datosContacto.html?se=" + ix);
}

function go_m8(part) {
	location.assign(lg + "_terminos.html?se=" + ix);
}

function go_m9(part) {
	location.assign(lg + "_resumen_rutas.html?se=" + ix);
}

function go_m10(part) {
	location.assign(lg + "_ContactoCoordina.html?se=" + ix);
}

function nada() {
	/* nada */
}

function salirapp() {
	save_ls("ls_user", "");
	save_ls("ls_pass", "");
	save_ls("ls_uuid", "");
	location.assign("index.html");
}

function obtener() {

	fileChooser.open(function (uri) {
		//   alert(uri);
		$("#filename").html(uri);
	});

}

function onAppReady() { /*if */

	if (navigator.splashscreen && navigator.splashscreen.hide) {   // Cordova API detected
		navigator.splashscreen.hide();
	}

	var string = device.isVirtual;
	console.log(string);

	if (string === false) {
		/* es equipo real*/

		//$("#info").val('APA91bGZKiU7QDzE7XyzN8QtNnCwj-xX5C3GKANpci2RSPWFgt9nMPfjU-0YtKxAgjPqP5Fwt_P08FByCDOfYxCQFVE9Q9NlrYvdL3xWo6DBRNKqCEqNc98');
		$("#botonx").html('<center class="txt1"><a href="javascript:go_login(\'0\');" class="btn btn-primary w-100 box-shadow-0 font-weight-light text-uppercase margin-top-10 text-white mt-2">' + txtactual[8] + '</a><center>');

	} else {
		/* es virtual */
		$("#info").val('APA91bGZKiU7QDzE7XyzN8QtNnCwj-xX5C3GKANpci2RSPWFgt9nMPfjU-0YtKxAgjPqP5Fwt_P08FByCDOfYxCQFVE9Q9NlrYvdL3xWo6DBRNKqCEqNc98');
		$("#botonx").html('<center class="txt1"><a href="javascript:go_login(\'0\');" class="btn btn-primary w-100 box-shadow-0 font-weight-light text-uppercase margin-top-10 text-white mt-2">' + txtactual[8] + '</a><center>');

	}
} /* ef */

var tokenID = "";
document.addEventListener("deviceready", onAppReady, false);
document.addEventListener("deviceready", Registrar_DEVICE, false);  /* end device ready */
document.addEventListener('backbutton', function (e) {
	//e.preventDefault();
	//  alert("back pres");
	//TODO: throw up your dialog here!
	go_m1();
}, true);

function Registrar_DEVICE() {

	try {
		/*  recorte */
		var push = PushNotification.init({
			android: {
				senderID: "542705093030"
			},
			browser: {
				pushServiceURL: 'http://push.api.phonegap.com/v1/push'
			},
			ios: {
				alert: "true",
				badge: "true",
				sound: "true"
			},
			windows: {}
		});

		/*  recorte */
		push.on('registration', function (data) {

			var ls_deviceid = get_ls("ls_deviceid");
			$("#info").val(ls_deviceid);
			var tam2 = $('#info').val().length;

			if (tam2 == 0 || ls_deviceid != data.registrationId) {
				//NO ESTA REGISTRADO , TRATAR DE REGISTRAR
				// showlogin("Registrando dispositivo..");
				tokenHandler(data.registrationId);
			} else {
				cordova.plugins.notification.badge.clear();
				//iniciar_app();
			}
		});

		push.on('notification', function (data) {
			// data.message,
			// data.title,
			// data.count,
			// data.sound,
			// data.image,
			// data.additionalData
		});

		push.on('error', function (e) {
			// e.message
		});

	} catch (err) {
		alert("Error Registration:" + err.message);
	}
}


function Revisar_DEVICE() {

	var ls_deviceid = get_ls("ls_deviceid");
	$("#info").val(ls_deviceid);
	var tam2 = $('#info').val().length;

	if (tam2 == 0) {
		//NO ESTA REGISTRADO , TRATAR DE REGISTRAR
		showlogin("Registrando dispositivo..");
		Registrar_DEVICE();
	} else {
		cordova.plugins.notification.badge.clear();
		//iniciar_app();
	}

}

//app given permission to receive and display push messages in Android.
function successHandler(result) {
	console.log('result = ' + result);
}

//app denied permission to receive and display push messages in Android.
function errorHandler(error) {
	console.log('error = ' + error);
}

//App given permission to receive and display push messages in iOS
function tokenHandler(result) {
	// Your iOS push server needs to know the token before it can push to this device
	// here is where you might want to send the token to your server along with user credentials.
	// alert('ios device token = ' + result);
	tokenID = result;
	$("#info").val(tokenID);
	// $("#info2").html('<i class="zmdi zmdi-cloud-done zmd-fw"></i>');
	$("#botonx").html('<center class="txt1"><a href="javascript:go_login(\'0\');" class="btn btn-primary w-100 box-shadow-0 font-weight-light text-uppercase margin-top-10 text-white mt-2">' + txtactual[8] + '</a><center>');
	showlogin(txtactual[8]);
}

//fired when token is generated, message is received or an error occured.
function onNotification(e) {

	switch (e.event) {
		//app is registered to receive notification
		case 'registered':
			if (e.regid.length > 0) {
				// Your Android push server needs to know the token before it can push to this device
				// here is where you might want to send the token to your server along with user credentials.
				//    alert('registration id = '+e.regid);
				tokenID = e.regid;
				$("#info").val(tokenID);
				// $("#info2").html('<i class="zmdi zmdi-cloud-done zmd-fw"></i>');
				$("#botonx").html('<center class="txt1"><a href="javascript:go_login(\'0\');" class="btn btn-primary w-100 box-shadow-0 font-weight-light text-uppercase margin-top-10 text-white mt-2">' + txtactual[8] + '</a><center>');
				$("#contenido").html("");
			}
			break;

		case 'message':
			//Do something with the push message. This function is fired when push message is received or if user clicks on the tile.
			//alert('message = '+e.message+' msgcnt = '+e.msgcnt);
			go_m5();
			break;

		case 'error':
			alert('GCM error = ' + e.msg);
			break;

		default:
			alert('An unknown GCM event has occurred');
			break;
	}
}

//callback fired when notification received in iOS
onNotificationAPN = function (e) {

	if (e.alert) {
		//do something with the push message. This function is fired when push message is received or if user clicks on the tile.
		alert(e.alert);
	}

	if (e.sound) {
		//play notification sound. Ignore when app is in foreground.
		// var snd = new Media(event.sound);
		// snd.play();
	}

	if (e.badge) {
		//change app icon badge number. If app is in foreground ignore it.
		window.plugins.pushNotification.setApplicationIconBadgeNumber(successHandler, errorHandler, e.badge);
	}
};