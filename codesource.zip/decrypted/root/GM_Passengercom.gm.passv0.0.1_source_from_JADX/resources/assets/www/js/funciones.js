function codigoTodas() {
	$("#txt_username").html(get_ls("ls_m_name"));
	$("#txt_company").html(get_ls("ls_m_company"));
	$("#txt_userid").html(get_ls("ls_m_userid"));	
	
	if (document.getElementById("enlaceBack")) {
		var ls_uuid = get_ls("ls_uuid");
		var ls_applg = get_ls("ls_applg");
		var enlaceBack = document.getElementById("enlaceBack");
		enlaceBack.href = ls_applg+"_main.html?se="+ls_uuid; 
	} 	

	console.log('paso antes procesar_option_def');
	var actual_option_def = get_ls("ls_opt");
	procesar_option_def(actual_option_def); // funcion para activar el menu	
	console.log('paso despues procesar_option_def');
	var enableBuyTickets = get_ls("enableBuyTickets");
	if (enableBuyTickets == 0) {
		$("#menu_comprar_ticket").hide();
	} 	
}

function initAjax() {

	$.ajaxSetup({
		url: URLAPPI,
		global: true,
		type: "POST",
		beforeSend: function (request) {
			request.setRequestHeader(SEKEYNAME, SEKEYVALUE);
		}
	});
}


function save_ls(lsname, lsvalue) {
	try {
		if (lsvalue == null || lsvalue == undefined) {
			lsvalue = "";
		}
		localStorage.setItem(lsname, lsvalue);

	} catch (err) {
		send_debug("save_ls", err.message);
	}


} /*ef*/

function get_ls(lsname) {
	try {
		var salida = localStorage.getItem(lsname);
		if (salida == undefined) {
			salida = "";
		}
		return salida;

	} catch (err) {
		send_debug("get_ls", err.message);
	}

}/*ef*/

/* ------- */
function send_debug(fname, info) {

	try {

		var urldebug = window.location.href;

		var ls_devplat = get_ls("ls_devplat");
		var ls_devver = get_ls("ls_devver");
		var ls_devman = get_ls("ls_devman");
		var ls_devmod = get_ls("ls_devmod");
		var ls_appver = get_ls("ls_appver");
		var ls_applg = get_ls("ls_applg");

		initAjax();

		var str = info;
		var info = str.replace(/'/g, "");

		var requestData = { cmd: "senddebug", functionname: fname, detalle: info, urldebug: urldebug, mplata: ls_devplat, version: ls_devver, manuf: ls_devman, model: ls_devmod, appjsver: ls_appver, applg: ls_applg, appname: APPJSNAME };

		$.ajax({ data: requestData })
			.done(function (data) { })
			.fail(function () { });

	} catch (err) {
		//alert("Local Error SendDebug: "+err.message);
	}

} /* ef */



/* ------- */
function set_language(objeto, attrname, txtvalue) {

	try {

		if (attrname.length == 0) {
			$(objeto).html(txtvalue);
		} else {
			$(objeto).attr(attrname, txtvalue);
		}

	} catch (err) {
		send_debug("set_language", err.message);
	}


} /* ef */


var get_params = function (search_string) {

	var parse = function (params, pairs) {
		var pair = pairs[0];
		var parts = pair.split('=');
		var key = decodeURIComponent(parts[0]);
		var value = decodeURIComponent(parts.slice(1).join('='));

		// Handle multiple parameters of the same name
		if (typeof params[key] === "undefined") {
			params[key] = value;
		} else {
			params[key] = [].concat(params[key], value);
		}

		return pairs.length == 1 ? params : parse(params, pairs.slice(1))
	}

	// Get rid of leading ?
	return search_string.length == 0 ? {} : parse({}, search_string.substr(1).split('&'));
}

/*  ----- */
function procesar_option_def(txt_option_def) {
	try {

		var str = txt_option_def;
		//console.log('txt_option_def: '+txt_option_def);
		var x = str.search("ALLTRIP");
		var b = str.search("ALLRES");
		var c = str.search("ALLACT");
		var d = str.search("ALLUB");
		var e = str.search("ALLCNT");

		var s = str.search("SRR");
		var d2d = str.search("SD2D");
		var staxi = str.search("STAXI");

		if (x >= 0) {
			//alert($("#menu_trip").length);
			//$("#menu_trip").css("display","block");
			//$("#menu_trip_gps").css("display","block");
			//$("#menu_trip_resumen").css("display","block");
			//$("#menu_contacto").css("display","block");

		}

		if (b >= 0) {
			$("#menu_trip_resumen").css("display", "block");
		}
		if (c >= 0) {
			$("#menu_trip").css("display", "block");
		}
		if (d >= 0) {
			$("#menu_trip_gps").css("display", "block");
		}
		if (e >= 0) {
			$("#menu_contacto").css("display", "block");
		}

		//Tipo
		if (s >= 0) {
			$("#regularOpt").css("display", "block");
		}

		if (d2d >= 0) {
			$("#d2d-opt").css("display", "block");
		}

		if (staxi >= 0) {
			$("#taxi-opt").css("display", "block");
		}





	} catch (err) {
		send_debug("procesar_option_def", err.message);
	}


}


function validartoken_rapido(uuidx, appTokenx) {
	try {

		var uuidx = get_ls("ls_uuid");
		var appTokenx = get_ls("ls_appToken");
		var deviceversionx = get_ls("ls_devver");
		var devicemanux = get_ls("ls_devman");
		var devicemodelx = get_ls("ls_devmod");
		var ID_device = get_ls("ls_deviceid");
		var app_version = get_ls("ls_appver");
		var app_plata = get_ls("ls_devplat");
		var applgx = get_ls("ls_applg");

		initAjax();

		var requestData = { cmd: "validartoken_rapido", uuid: uuidx, appToken: appTokenx, ID_device: ID_device, app_version: app_version, app_plata: app_plata, deviceversion: deviceversionx, devicemanu: devicemanux, devicemodel: devicemodelx, applg: applgx };

		$.ajax({ data: requestData })
			.done(function (data) {
				var obj = JSON.parse(data);

				if (obj.respuesta == 1) {
					console.log("MANTENER EN EL APP");
				} else {
					console.log("SACAR DEL APP");
					salirapp();
				}

			})
			.fail(function () {

			});
	} catch (error) {

	}
}


function getRandomIntInclusive(min, max) {
	try {
		min = Math.ceil(min);
		max = Math.floor(max);
		return Math.floor(Math.random() * (max - min + 1)) + min; //The maximum is inclusive and the minimum is inclusive 
	} catch (err) {
		send_debug("getRandomIntInclusive", err.message);
	}
}



function wp_alerta(titulo, texto) {
	try {
		$.alert({
			title: titulo,
			content: texto,
			type: 'red'
		});

	} catch (err) {
		send_debug("wp_alerta", err.message);
	}

}

function sp_alerta(titulo, texto) {
	try {
		$.alert({
			title: titulo,
			content: texto,
			type: 'green'
		});

	} catch (err) {
		send_debug("wp_alerta", err.message);
	}

}



function gotourl(url_destino) {
	try {

		location.assign(url_destino);

	} catch (err) {
		send_debug("gotourl", err.message);
	}


}


function isEmpty(MyVar) {

	return (

		(typeof MyVar == 'undefined')        //undefined
		||
		(MyVar == null)                     //null
		||
		(MyVar == false)  //!MyVariable     //false
		||
		(MyVar.length == 0)                 //empty
		||
		(MyVar == "")                       //empty
		||
		(MyVar.replace(/\s/g, "") == "")     //empty
		||
		(!/[^\s]/.test(MyVar))              //empty
		||
		(/^\s*$/.test(MyVar))                //empty
	);

}



function ObjectLength(object) {
	var length = 0;
	for (var key in object) {
		if (object.hasOwnProperty(key)) {
			++length;
		}
	}
	return length;
};


function countProperties(obj) {
	var count = 0;

	for (var property in obj) {
		if (Object.prototype.hasOwnProperty.call(obj, property)) {
			count++;
		}
	}

	return count;
}

function initClock2() {
	//AJAX
	initAjax();
	// [{"tpx":"589841","lat":"1.5555555555","lng":"-88.010101010101","stopId":"0","employeeId":"4101","origen":"testoscar"}]
	var requestData = { //Just the first TS on the list
		cmd: "clock_info"
	};
	$.ajax({
		data: requestData
	})
		.done(function (dataReturn) {
			var obj = JSON.parse(dataReturn);
			console.log(obj);
			if (obj.resultado == '1') {
				h = parseInt(obj.hour);
				m = parseInt(obj.minutes);
				s = parseInt(obj.seconds);
				dia = parseInt(obj.dia);
				mes = parseInt(obj.mes);
				clock();
			}
			console.log(obj.resultado);
		})
		.fail(function () {
			console.log("OCURRIO ALGUN PROBLEMA CON EL RELOG");
		});
	//AJAX
}

function clock() {
	lg = get_ls('ls_applg');
	s = s + 1

	if (s == 60) {
		s = 0
		m = m + 1
		if (m == 60) {
			m = 0
			h = h + 1
			if (h == 24) {
				h = 0;
			}
		}
	}

	if (h < 10) {
		hh = '0' + h;
	} else {
		hh = h;
	}

	if (m < 10) {
		mm = '0' + m;
	} else {
		mm = m;
	}

	if (s < 10) {
		ss = '0' + s;
	} else {
		ss = s;
	}

	switch (mes) {
		case 1:
			if(lg == 'es'){
				textMes = "Ene";
			}else{
				textMes = "Jan";
			}
		break;
		case 2:
			textMes = "Feb";
		break;
		case 3:
			textMes = "Mar";
		break;
		case 4:
			if(lg == 'es'){
				textMes = "Abr";
			}else{
				textMes = "Apr";
			}			
		break;
		case 5:
			textMes = "May";
		break;
		case 6:
			textMes = "Jun";
		break;
		case 7:
			textMes = "Jul";
		break;
		case 8:
			if(lg == 'es'){
				textMes = "Ago";
			}else{
				textMes = "Aug";
			}			
		break;
		case 9:
			if(lg == 'es'){
				textMes = "Set";
			}else{
				textMes = "Sep";
			}			
		break;
		case 10:
			textMes = "Oct";
		break;
		case 11:
			textMes = "Nov";
		break;
		case 12:
			if(lg == 'es'){
				textMes = "Dic";
			}else{
				textMes = "Dec";
			}			
		break;																																												
	}

	//horaImprimible = getDate();
	//horaImprimible = new Date();
	//mesImprimible = horaImprimible.getMonth();

	// document.getElementById('clock-s').innerHTML
	//document.form_reloj.reloj.value = horaImprimible + mesImprimible + " " + hh + ":" + mm;
	/*
	const month = new Array();
	month[0] = "Ene";
	month[1] = "Feb";
	month[2] = "Mar";
	month[3] = "Abr";
	month[4] = "May";
	month[5] = "Jun";
	month[6] = "Jul";
	month[7] = "Ago";
	month[8] = "Set";
	month[9] = "Oct";
	month[10] = "Nov";
	month[11] = "Dic";

	const d = new Date();
	let mesMes = month[d.getMonth()];

	let day = d.getDay();
	*/
	
	//document.form_reloj.reloj.value = horaImprimible + " <span class='icon ml-2 fas fa-clock'></span>" + hh + ":" + mm;
// <span class="date ml-2 fecha">Oct 26</span><span><span class="icon ml-2 fas fa-clock"></span> 05:37 PM</span>
	document.getElementById('clock-s').innerHTML = ' - '+ textMes + ' ' + dia +'<span class="icon ml-2 fas fa-clock"></span> '+ hh + ":" + mm;
	//document.form_reloj.reloj.value = mesMes + day + hh + ":" + mm;
	var t = setTimeout(clock, 1000);
}