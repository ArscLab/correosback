//Efectos (llamar/mostrar datos)
function tipoRutaClick(DomObj){
	try{
		$(".tipoRuta").hide();
		$(".recuadro.selectedOptions").show();
		$(".sentido").show();

		$(".formReservations hr").show();
		$(".selectedOptions").show();

		//Dato info visible al usuario
		var tipoRutaSelected = $(DomObj).text();
		//alert(tipoRutaSelected);
		$(".selectedOptions>ul").append("<li class='tipoLi status-container'><input onclick='tipoRutaClickReturn()' type='text' name='tipoRuta' value='"+tipoRutaSelected+"' readonly='' /> </li>");

		//Dato info para proceso back
		var routeTypeId = $(DomObj).attr("val");
		$("input[name='routeTypeId']").val(routeTypeId);

	}catch(err) {
		//alert("Error:"+err.message);
		send_debug("tipoRutaClick",err.message);
	}
} /* ef */
function tipoRutaClickReturn(){
	try{
		$(".selectedOptions>ul>li").remove();
		$(".recuadro.selectedOptions").hide();
		$(".tipoRuta").show();

		$(".sentido,.ruta,.hora,.parada,.dias,.confirmar").hide();
		$(".tipoLi,.sentidoLi,.rutaLi,.horaLi,.paradaLi,.diasLi").remove();

		$("input[name='routeTypeId']").val(0);
		$("input[name='routeWayId']").val(0);
		$("input[name='routeId']").val(0);
		$("input[name='routeItineraryId']").val(0);
		$("input[name='stopId']").val(0);
		$("input[name='dias']").val(0);

	}catch(err) {
		//alert("Error:"+err.message);
		send_debug("tipoRutaClickReturn",err.message);
	}
} /* ef */


function SentidoClick(DomObj){
	try{
		$(".sentido").hide();
		$(".ruta").show();
		//alert('sentido go');
		//Dato info visible al usuario
		var sentidoSelected = $(DomObj).text();
		var tipox=$("input[name='routeTypeId']").val();
	
		$(".selectedOptions>ul").append("<li class='sentidoLi status-container'><input  onclick='SentidoClickReturn()' type='text' name='sentido' value='"+sentidoSelected+"' readonly='' /> </li>");

		//Dato info para proceso back
		var routeWayId = $(DomObj).attr("val");
		$("input[name='routeWayId']").val(routeWayId);

		//alert(tipox);
		//alert(routeWayId);
		getRoutes(ix,routeWayId,tipox);
		//habilitarRetroceso();
	}catch(err) {
		//alert("Error:"+err.message);
		send_debug("SentidoClick",err.message);
	}
} /* ef */
function SentidoClickReturn(){
	try{
		//alert('sentido return');
		$(".sentido").show();
		$(".tipoRuta,.ruta,.hora,.parada,.dias,.confirmar").hide();

		$(".sentidoLi,.rutaLi,.horaLi,.paradaLi,.diasLi").remove();


		$("input[name='routeWayId']").val(0);
		$("input[name='routeId']").val(0);
		$("input[name='routeItineraryId']").val(0);
		$("input[name='stopId']").val(0);
		$("input[name='dias']").val(0);

	}catch(err) {
		//alert("Error:"+err.message);
		send_debug("SentidoClickReturn",err.message);
	}
} /* ef */


function RutaClick(DomObj){
	try{
		//alert('ruta go ');
		//alert("Ruta. Ej: Alajuela - Heredia");
		$(".ruta").hide();
		$(".hora").show();

		//Dato info visible al usuario
		var rutaSelected = $(DomObj).text();
		//alert("ojo:"+rutaSelected);
		$(".selectedOptions>ul").append("<li class='rutaLi status-container'><input onclick='RutaClickReturn();' type='text' name='ruta' value='"+rutaSelected+"' readonly='' /> </li>");

		//Dato info para proceso back
		var routeId = $(DomObj).attr("val");
		$("input[name='routeId']").val(routeId);

		//alert("ojo:"+routeId);
		getHours(ix,routeId);

		//habilitarRetroceso();

	}catch(err) {
		//alert("Error:"+err.message);
		send_debug("RutaClick",err.message);
	}
} /* ef */
function RutaClickReturn(){
	try{
		//alert('ruta return');
		$(".ruta").show();
		$(".tipoRuta,.sentido,.hora,.parada,.dias,.confirmar").hide();

		$(".rutaLi,.horaLi,.paradaLi,.diasLi").remove();

		var tipox=$("input[name='routeTypeId']").val();
		var routeWayId = $("input[name='routeWayId']").val();


		$("input[name='routeId']").val(0);
		$("input[name='routeItineraryId']").val(0);
		$("input[name='stopId']").val(0);
		$("input[name='dias']").val(0);
		
		getRoutes(ix,routeWayId,tipox);


	}catch(err) {
		//alert("Error:"+err.message);
		send_debug("RutaClickReturn",err.message);
	}
} /* ef */


function HoraClick(DomObj){
	try{
		//alert('hora go');
		//alert("Hora. Ej: 7:00 am");
		$(".hora").hide();
		
		//Dato info visible al usuario
		var horaSelected = $(DomObj).text();
		$(".selectedOptions>ul").append("<li class='horaLi status-container'><input onclick='HoraClickReturn();' type='text' name='hora' value='"+horaSelected+"' readonly='' /> </li>");
		
		//Dato info para proceso back
		var routeItineraryId = $(DomObj).attr("val");
		//alert(routeItineraryId);
		$("input[name='routeItineraryId']").val(routeItineraryId);

		var routeId = $("input[name='routeId']").val();
		
		//Revisar Tipo de Ruta: Regular o D2D
		var tempTipoVal = $("input[name='routeTypeId']").val();
		if (tempTipoVal=='4'){
			//Si es regular, va a: parada
			$(".parada").show();

			//alert(routeId+" "+routeItineraryId);
			getStops(ix,routeId,routeItineraryId);
		}
		else{
			//Si es D2D, va a: dias
			$(".dias").show();

			getDiasClean(ix,routeId,routeItineraryId);
		}

		//habilitarRetroceso();

	}catch(err) {
		//alert("Error:"+err.message);
		send_debug("HoraClick",err.message);
	}
} /* ef */
function HoraClickReturn(){
	try{
		//alert('hora return');
		$(".hora").show();
		$(".tipoRuta,.sentido,.ruta,.parada,.dias,.confirmar").hide();

		$(".horaLi,.paradaLi,.diasLi").remove();

		var routeId =$("input[name='routeId']").val();


		$("input[name='routeItineraryId']").val(0);
		$("input[name='stopId']").val(0);
		$("input[name='dias']").val(0);

		//alert("ojo:"+routeId);
		getHours(ix,routeId);

	}catch(err) {
		//alert("Error:"+err.message);
		send_debug("HoraClickReturn",err.message);
	}
} /* ef */


function ParadaClick(DomObj){
	try{
		//alert("Parada. Ej: Entrada Principal del Pali Pacifico");
		$(".parada").hide();
		$(".dias").show();

		//Dato info visible al usuario
		var paradaSelected = $(DomObj).text();
		//alert(paradaSelected);
		$(".selectedOptions>ul").append("<li class='paradaLi'><input onclick='ParadaClickReturn();' type='text' name='parada' value='"+paradaSelected+"' readonly='' /> </li>");

		//Dato info para proceso back
		var stopId = $(DomObj).attr("val");
		$("input[name='stopId']").val(stopId);

		//get_dates();
		//	habilitarRetroceso();
		var routeId = $("input[name='routeId']").val();
		var routeItineraryId = $("input[name='routeItineraryId']").val();
		getDiasClean(ix,routeId,routeItineraryId);

	}catch(err) {
		//alert("Error:"+err.message);
		send_debug("ParadaClick",err.message);
	}
} /* ef */
function ParadaClickReturn(){
	try{
		//	alert('parada return');
		$(".parada").show();
		$(".ruta,.hora,.dias").hide();

		$(".paradaLi,.diasLi").remove();

		$("input[name='stopId']").val(0);
		$("input[name='dias']").val(0);

	}catch(err) {
		//alert("Error:"+err.message);
		send_debug("ParadaClickReturn",err.message);
	}
} /* ef */

