//Idioma
lg = get_ls("ls_applg");
//alert(lg);

function activar_timer(){
	var timer00= setInterval(function(){ gogps(); }, 10000); 
}

function detener_timer(){
	clearInterval(timer00); 
}


function obtener_pos(){
    if (lg=='en'){
		var txt = 'Searching GPS...';
    }else{
		var txt = 'Buscando GPS...';
	}
	$("#info").html('<i class="zmdi-hc-li zmdi zmdi-refresh zmdi-hc-spin"></i>'+txt);
	navigator.geolocation.getCurrentPosition(show ,er,{maximumAge: 3000, timeout: 7000, enableHighAccuracy: true});    
}


var show =function show_mapa(position){
	if (lg=='en'){
		var txt1 = 'Great! Using your location.';
		var txt2 = 'Update GPS';
		var txt3 = 'Continue';
	}else{
		var txt1 = '¡Genial! Usando tu ubicaci\u00F3n.';
		var txt2 = 'Actualizar GPS';
		var txt3 = 'Continuar';
	}
	$("#info").html('<i class="zmdi zmdi-check"></i> '+txt1+'<br><br><a id="regresar" href="javascript:gogps();" class="ui-btn ui-btn-raised clr-primary btn btn-primary w-100 box-shadow-0 font-weight-light text-uppercase margin-top-10 text-white"  data-ajax="false"><i class="zmdi zmdi-refresh"></i> '+txt2+'</a> <br> <a id="regresar" href="javascript:save_datos();" class="ui-btn ui-btn-raised clr-primary btn btn-primary w-100 box-shadow-0 font-weight-light text-uppercase margin-top-10 text-white"  data-ajax="false"> '+txt3+' </a>');
    
	//  $("#info").html('Genial Usando tu ubicacion: ' + position.coords.latitude  + '/'+ position.coords.longitude +'<a id="regresar" href="javascript:gogps();" class="ui-btn ui-btn-raised clr-primary"  data-ajax="false">Actualizar GPS</a>');
    
    $("#lat").val(position.coords.latitude);
    $("#log").val(position.coords.longitude);
    $("#listo").val(1);


	//	alert("info "+ position.coords.latitude);
	// $("#info").html('Lat: ' + position.coords.latitude  + ' Long: '+ position.coords.longitude);

	//navigator.vibrate(200);

	var mapProp = {center:new google.maps.LatLng(position.coords.latitude,position.coords.longitude), zoom:16, mapTypeId:google.maps.MapTypeId.ROADMAP,disableDefaultUI: true};
	var map=new google.maps.Map(document.getElementById("map"), mapProp);
	var marker=new google.maps.Marker({
		position:new google.maps.LatLng(position.coords.latitude,position.coords.longitude),
		draggable:true
	});
	marker.setMap(map); 

	google.maps.event.addListener(marker,'dragend',function(event) {

		$("#lat").val(this.position.lat());
		$("#log").val(this.position.lng());
		$("#listo").val(1);
		// alert('Drag end');
	});
};


var er=function show_err(err){
	if (lg=='en'){
		var txt1 = 'GPS Error. Try again';
		var txt2 = 'Update GPS';
	}else{
		var txt1 = 'Error en el GPS. Int\u00E9ntelo Nuevamente';
		var txt2 = 'Actualizar GPS';
	}
	
	$("#info").html('<i class="zmdi zmdi-close"></i> '+txt1+'<br><a id="regresar" href="javascript:gogps();" class="ui-btn ui-btn-raised clr-primary"  data-ajax="false"><i class="zmdi zmdi-refresh"></i> '+txt2+'</a>'); 
    
};


function gogps(){
    obtener_pos();   
}
