var URLAPPI = "https://eme5auutkk-prod.globalmobility.click/gm-pass/v1/";
var APPJSVERSION = "V08";
var SEKEYNAME = "hht";
var SEKEYVALUE = "mezdbkicklpsxleehtrh";
var APPJSNAME = "GMPassenger";