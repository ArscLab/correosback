            //Unregister the previous token because it might have become invalid. Unregister everytime app is started.
         window.plugins.pushNotification.unregister(successHandler, errorHandler);
           
           // alert(device.platform);
            
            if(device.platform == "Android"){
                //register the user and get token
                window.plugins.pushNotification.register(
                successHandler,
                errorHandler,
                {
                    //senderID is the project ID
                    "senderID":"632855775750",
                    //callback function that is executed when phone recieves a notification for this app
                    "ecb":"onNotification"
                });
                
            }else if(device.platform == "iOS"){
                //register the user and get token
                window.plugins.pushNotification.register(
                tokenHandler,
                errorHandler,
                {
                    //allow application to change badge number
                    "badge":"true",
                    //allow application to play notification sound
                    "sound":"true",
                    //register callback
                    "alert":"true",
                    //callback function name
                    "ecb":"onNotificationAPN"
                });
            }


            //comentario demo


