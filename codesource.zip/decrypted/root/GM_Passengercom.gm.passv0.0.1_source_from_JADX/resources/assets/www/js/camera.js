function obtener_v2(){
try {
    navigator.camera.getPicture(getFileEntry_v2, onFail_ca, { quality: 50,
    destinationType: Camera.DestinationType.FILE_URI, saveToPhotoAlbum: true });
}
catch(err) {
    alert("error;"+err.message);
}

}

//---------

function obtener(){
try {
    navigator.camera.getPicture(getFileEntry, onFail_ca, { quality: 50,
    destinationType: Camera.DestinationType.FILE_URI, saveToPhotoAlbum: true });
}
catch(err) {
    alert("error;"+err.message);
}

}



var preventDefaultScroll = function(event) 
{
    // Prevent scrolling on this element
    event.preventDefault();
    window.scroll(0,0);
    return false;
};
    
//window.document.addEventListener("touchmove", preventDefaultScroll, false);


function obtenerlib(){
navigator.camera.getPicture(getFileEntry, onFail_ca,
{
    destinationType: Camera.DestinationType.FILE_URI,
    sourceType: Camera.PictureSourceType.PHOTOLIBRARY
});
}

function obtenerlib_v2(){
navigator.camera.getPicture(getFileEntry_v2, onFail_ca,
{
    destinationType: Camera.DestinationType.FILE_URI,
    sourceType: Camera.PictureSourceType.PHOTOLIBRARY
});
}

function obtenerFile(){
fileChooser.open(function(uri) {
   // alert(uri);
    getFileEntry(uri);
});
}
    
function onSuccess_ca(imageURI) {
    var image = document.getElementById('myImage');
    image.src = imageURI;
}

function onFail_ca(message) {
     $("#filename").val('');
    $("#info").html('');
   //alert('Failed because: ' + message);
}



function getFileEntry_v2(imgUri) {
    window.resolveLocalFileSystemURL(imgUri, function success(fileEntry) {
 
     
       //alert("got file: " + fileEntry.nativeURL);
        //$("#filename").val(fileEntry.nativeURL);
      //  $("#info").html('<i class="zmdi zmdi-file zmd-fw"></i>  Imagen Seleccionada.');
		var id_inspx = $("#id_insp").val();
		var ix = $("#i").val();
      subir_doc_v2(id_inspx,ix,fileEntry.nativeURL);
 
    }, function () {
      // If don't get the FileEntry (which may happen when testing 
      // on some emulators), copy to a new FileEntry. 
        //createNewFileEntry(imgUri);
    });
}



function getFileEntry(imgUri) {
    
    
    
    window.resolveLocalFileSystemURL(imgUri, function success(fileEntry) {
 
        // Do something with the FileEntry object, like write to it, upload it, etc. 
        // writeFile(fileEntry, imgUri); 
        
       //alert("got file: " + fileEntry.nativeURL);
        $("#filename").val(fileEntry.nativeURL);
        $("#info").html('<i class="zmdi zmdi-file zmd-fw"></i>  Imagen Seleccionada.');
        // displayFileData(fileEntry.nativeURL, "Native URL"); 
 
    }, function () {
      // If don't get the FileEntry (which may happen when testing 
      // on some emulators), copy to a new FileEntry. 
        //createNewFileEntry(imgUri);
    });
    
    
}



//-----------------

function win(r) {
    //alert("response = " + r.response);
    console.log("Code = " + r.responseCode);
    console.log("Response = " + r.response);
    console.log("Sent = " + r.bytesSent);
    if(r.response=="ok"){
    $("#info").html('<i class="zmdi zmdi-check zmd-fw"></i> Completo ... 100%');
    $("#filename").val('');
    }
    
    
    if(r.response=="fail"){
    $("#info").html('<i class="zmdi zmdi-close-circle zmd-fw"></i> No se pudo completar la tarea.');
    $("#filename").val('');
    }
    
    }
	
	
function win_v2(r) {


    if(r.response=="ok"){
	$( "#loadimginfo" ).append('<i class="zmdi zmdi-check zmd-fw"></i> Imagen Cargada !<br>');
    }
    
    
    if(r.response=="fail"){
	$( "#loadimginfo" ).append('<i class="zmdi zmdi-close-circle zmd-fw"></i> Fallo al cargar. (e1)<br>');
    }
    
    }	
	
 
function fail(error) {
    //alert("An error has occurred: Code = " + error.code);
    console.log("upload error source " + error.source);
    console.log("upload error target " + error.target);
      $("#filename").val('');
}


function fail_v2(error) {
    //alert("An error has occurred: Code = " + error.code);
    console.log("upload error source " + error.source);
    console.log("upload error target " + error.target);
    $( "#loadimginfo" ).append('<i class="zmdi zmdi-close-circle zmd-fw"></i> Fallo al cargar. (e2)<br>');
}

function subir(chid,doc,idv,i){
    
var tam=$('#filename').val().length;

if(tam===0){
	alert("Debes seleccionar una imagen.");
	return;
}    
    
var options = new FileUploadOptions();
options.fileKey = "file";
options.fileName = $("#filename").val();
//options.fileName = fileURL.substr(fileURL.lastIndexOf('/') + 1);
//options.mimeType = "image/jpeg";
 
    
//alert($("#filename").html());

var params = {};
params.value1 = "test";
params.value2 = "param";
 
options.params = params;
 
var ft = new FileTransfer();
fileURL=$("#filename").val();
    
ft.onprogress = function(progressEvent) {
    if (progressEvent.lengthComputable) {
        
        final=(progressEvent.loaded / progressEvent.total)*100;
        $("#info").html('<i class="zmdi zmdi-cloud-upload zmd-fw"></i>Subiendo ... '+final.toFixed(2) + "%");
        
    } else {
        final=(progressEvent.loaded / progressEvent.total)*100;
           $("#info").html('<i class="zmdi zmdi-cloud-upload zmd-fw"></i>Subiendo ... '+final.toFixed(2) + "%");
    }
};    
    
ft.upload(fileURL, encodeURI("http://globalmobility.cr/rutas/api/v1/upload.php?chid="+chid+"&doc="+doc+"&idv="+idv+"&i="+i), win, fail, options);
    
    
    
}

//--------------------------
function subir_doc(idinspe,i){
    
var tam=$('#filename').val().length;

if(tam===0){
    alert("Debes seleccionar una imagen.");
    return;
}    
    
var options = new FileUploadOptions();
options.fileKey = "file";
options.fileName = $("#filename").val();
//options.fileName = fileURL.substr(fileURL.lastIndexOf('/') + 1);
options.mimeType = "image/jpeg";   
//alert($("#filename").html());

var params = {};
params.value1 = "test";
params.value2 = "param";
 
options.params = params;
 
var ft = new FileTransfer();
fileURL=$("#filename").val();
    
ft.onprogress = function(progressEvent) {
    if (progressEvent.lengthComputable) {
        
        final=(progressEvent.loaded / progressEvent.total)*100;
        $("#info").html('<i class="zmdi zmdi-cloud-upload zmd-fw"></i>Subiendo ... '+final.toFixed(2) + "%");
        
    } else {
        final=(progressEvent.loaded / progressEvent.total)*100;
           $("#info").html('<i class="zmdi zmdi-cloud-upload zmd-fw"></i>Subiendo ... '+final.toFixed(2) + "%");
    }
};    
    
ft.upload(fileURL, encodeURI("http://globalmobility.cr/rutas/api/v1/v2_upload.php?idinspe="+idinspe+"&i="+i), win, fail, options);
    

}

//--------------------------
function subir_doc_v2(idinspe,i,fileuse){
    

    
var options = new FileUploadOptions();
options.fileKey = "file";
options.fileName = fileuse;
//options.fileName = fileURL.substr(fileURL.lastIndexOf('/') + 1);
//options.mimeType = "image/jpeg";   
//alert($("#filename").html());

var params = {};
params.value1 = "test";
params.value2 = "param";
 
options.params = params;
 
var ft = new FileTransfer();
fileURL=fileuse;
    
ft.onprogress = function(progressEvent) {
    if (progressEvent.lengthComputable) {
        
        final=(progressEvent.loaded / progressEvent.total)*100;
        //$("#info").html('<i class="zmdi zmdi-cloud-upload zmd-fw"></i>Subiendo ... '+final.toFixed(2) + "%");
        
    } else {
        final=(progressEvent.loaded / progressEvent.total)*100;
           //$("#info").html('<i class="zmdi zmdi-cloud-upload zmd-fw"></i>Subiendo ... '+final.toFixed(2) + "%");
    }
};    
    
ft.upload(fileURL, encodeURI("http://globalmobility.cr/rutas/api/v1/v2_upload.php?idinspe="+idinspe+"&i="+i), win_v2, fail_v2, options);
    

}