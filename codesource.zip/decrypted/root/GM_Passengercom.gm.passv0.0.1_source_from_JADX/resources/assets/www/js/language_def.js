textout_es=[];
//index
//Texto plano
textout_es[0]="Bienvenido(a)";
textout_es[1]="Preparando ...";
textout_es[2]="Ingrese sus credenciales.";
textout_es[3]="Usuario";
textout_es[4]="Contraseña";
textout_es[5]="Recuperar acceso";
textout_es[6]="Código de Activación";
textout_es[7]="Favor ingresar sus datos";
//Validación
textout_es[8]="ENTRAR";
textout_es[9]="Ingrese su usuario.";
textout_es[10]="Ingrese su contraseña.";
textout_es[11]="Registrando Dispositivo. Inténtelo nuevamente.";
textout_es[12]="No se logro verificar su acceso. Por favor inténtelo nuevamente";
textout_es[13]="Favor verificar sus datos";
textout_es[14]="Datos incorrectos";
textout_es[15]="ENTRANDO...";
textout_es[16]="Política de privacidad";


textout_en=[];
//index
//Texto plano
textout_en[0]="Welcome";
textout_en[1]="Working ...";
textout_en[2]="Insert your username and password.";
textout_en[3]="Username";
textout_en[4]="Password";
textout_en[5]="Recover Access";
textout_en[6]="Activate with code";
textout_en[7]="Please complete with your information";
//Validación
textout_en[8]="LOG IN";
textout_en[9]="Insert your username.";
textout_en[10]="Insert your password";
textout_en[11]="Registering Device. Please try again.";
textout_en[12]="We can not verify your access. Please try again";
textout_en[13]="Please verify your information";
textout_en[14]="Incorrect username or password";
textout_en[15]="ENTERING...";
textout_en[16]="Privacy Policy";

