//Idioma
lg = get_ls("ls_applg");
//alert("lg"+lg);
function SiteClickReturn(DomObj) {
	try {

		$(".selectedOptions>ul>li").remove();
		$(".recuadro.selectedOptions,#mapaParadas,.btnsMapPards").hide();
		$(".tipoRuta").show();

		$(".sentido,.ruta,.hora,.parada,.dias,.confirmar,.gMapsIcon,#horaLimite").hide();
		$(".tipoLi,.sentidoLi,.rutaLi,.horaLi,.paradaLi,.diasLi").remove();
		$(".seat-row").remove();

		$("input[name='routeTypeId']").val(0);
		$("input[name='routeWayId']").val(0);
		$("input[name='routeId']").val(0);
		$("input[name='routeItineraryId']").val(0);
		$("input[name='stopId']").val(0);
		$("input[name='dias']").val(0);

		$("#regularOpt").css("display", "none");
		$("#d2d-opt").css("display", "none");
		$("#taxi-opt").css("display", "none");

		$("#temp1").show();
		loadpage(ix);

	} catch (err) {
		//alert("Error:"+err.message);
		send_debug("SiteClickReturn", err.message);
	}
} /* ef */

function SiteClick(DomObj) {
	try {

		//Dato info para proceso back
		var siteId = $(DomObj).attr("val");
		$("input[name='siteId']").val(siteId);
		$("#titulo").html("Tipo");
		$(".SiteOpt").css("display", "none");
		$("#temp1").show();

		mostrar_botones(ix);

		var SiteSelected = $(DomObj).text();
		//alert(tipoRutaSelected);
		$(".selectedOptions>ul").append("<li class='tipoLi'><input onclick='SiteClickReturn()' type='text' name='tipoRuta' value='" + SiteSelected + "' readonly='' /> </li>");


	} catch (err) {
		//alert("Error:"+err.message);
		send_debug("SiteClick", err.message);
	}
} /* ef */

//Efectos para Realizar Reservacion (y llamar/mostrar datos)
function tipoRutaClick(DomObj) {
	try {
		$(".tipoRuta").hide();
		$(".recuadro.selectedOptions").show();
		$(".sentido").show();

		$(".formReservations hr").show();
		$(".selectedOptions").show();

		//Dato info visible al usuario
		var tipoRutaSelected = $(DomObj).text();
		//alert(tipoRutaSelected);
		$(".selectedOptions>ul").append("<li class='tipoLi'><input onclick='tipoRutaClickReturn()' type='text' name='tipoRuta' value='" + tipoRutaSelected + "' readonly='' class='btn btn-primary w-100 box-shadow-0 font-weight-light text-uppercase text-white'/> </li>");

		//Dato info para proceso back
		var routeTypeId = $(DomObj).attr("val");
		$("input[name='routeTypeId']").val(routeTypeId);

		getSentido(ix, routeTypeId);

	} catch (err) {
		//alert("Error:"+err.message);
		send_debug("tipoRutaClick", err.message);
	}
} /* ef */


function tipoRutaClickReturn() {
	try {
		$(".selectedOptions>ul>li").remove();
		$(".recuadro.selectedOptions,#mapaParadas,.btnsMapPards").hide();
		$(".tipoRuta").show();

		$(".sentido,.ruta,.hora,.parada,.dias,.confirmar,.gMapsIcon").hide();
		$(".tipoLi,.sentidoLi,.rutaLi,.horaLi,.paradaLi,.diasLi").remove();
		$(".seat-row").remove();

		$("input[name='routeTypeId']").val(0);
		$("input[name='routeWayId']").val(0);
		$("input[name='routeId']").val(0);
		$("input[name='routeItineraryId']").val(0);
		$("input[name='stopId']").val(0);
		$("input[name='dias']").val(0);

	} catch (err) {
		//alert("Error:"+err.message);
		send_debug("tipoRutaClickReturn", err.message);
	}
} /* ef */


function SentidoClick(DomObj) {
	try {

		$(".sentido").hide();
		$(".ruta").show();
		//alert('sentido go');
		//Dato info visible al usuario
		var sentidoSelected = $(DomObj).text();
		var tipox = $("input[name='routeTypeId']").val();

		$(".selectedOptions>ul").append("<li class='sentidoLi'><input  onclick='SentidoClickReturn()' type='text' name='sentido' value='" + sentidoSelected + "' readonly='' class='btn btn-primary w-100 box-shadow-0 font-weight-light text-uppercase text-white margin-top-10'/> </li>");

		//Dato info para proceso back
		var routeWayId = $(DomObj).attr("val");
		$("input[name='routeWayId']").val(routeWayId);

		//alert(tipox);
		//alert(routeWayId);
		getRoutes(ix, routeWayId, tipox);
		//habilitarRetroceso();
	} catch (err) {
		//alert("Error:"+err.message);
		send_debug("SentidoClick", err.message);
	}
} /* ef */
function SentidoClickReturn() {
	try {

		//alert('sentido return');
		$(".sentido").show();
		$(".tipoRuta,.ruta,.hora,.parada,.dias,.confirmar,.gMapsIcon,#mapaParadas,.btnsMapPards").hide();

		$(".sentidoLi,.rutaLi,.horaLi,.paradaLi,.diasLi").remove();
		$(".seat-row").remove();


		$("input[name='routeWayId']").val(0);
		$("input[name='routeId']").val(0);
		$("input[name='routeItineraryId']").val(0);
		$("input[name='stopId']").val(0);
		$("input[name='dias']").val(0);

	} catch (err) {
		//alert("Error:"+err.message);
		send_debug("SentidoClickReturn", err.message);
	}
} /* ef */


function RutaClick(DomObj) {
	try {

		//alert('ruta go ');
		//alert("Ruta. Ej: Alajuela - Heredia");
		$(".ruta").hide();
		$(".hora").show();

		//Dato info visible al usuario
		var rutaSelected = $(DomObj).text();
		//alert("ojo:"+rutaSelected);
		$(".selectedOptions>ul").append("<li class='rutaLi'><input onclick='RutaClickReturn();' type='text' name='ruta' value='" + rutaSelected + "' readonly=''  class='btn btn-primary w-100 box-shadow-0 font-weight-light text-uppercase text-white margin-top-10'/> </li>");

		//Dato info para proceso back
		var routeId = $(DomObj).attr("val");
		$("input[name='routeId']").val(routeId);

		//alert("ojo:"+routeId);
		getHours(ix, routeId);

		//habilitarRetroceso();

	} catch (err) {
		//alert("Error:"+err.message);
		send_debug("RutaClick", err.message);
	}
} /* ef */
function RutaClickReturn() {
	try {

		//alert('ruta return');
		$(".ruta").show();
		$(".tipoRuta,.sentido,.hora,.parada,.dias,.confirmar,.gMapsIcon,#mapaParadas,.btnsMapPards").hide();

		$(".rutaLi,.horaLi,.paradaLi,.diasLi").remove();
		$(".seat-row").remove();

		var tipox = $("input[name='routeTypeId']").val();
		var routeWayId = $("input[name='routeWayId']").val();


		$("input[name='routeId']").val(0);
		$("input[name='routeItineraryId']").val(0);
		$("input[name='stopId']").val(0);
		$("input[name='dias']").val(0);

		getRoutes(ix, routeWayId, tipox);


	} catch (err) {
		//alert("Error:"+err.message);
		send_debug("RutaClickReturn", err.message);
	}
} /* ef */


function HoraClick(DomObj) {
	try {
		//alert('hora go');
		//alert("Hora. Ej: 7:00 am");
		$(".hora").hide();
		$(".gMapsIcon").show();

		//Dato info visible al usuario
		var horaSelected = $(DomObj).text();
		$(".selectedOptions>ul").append("<li class='horaLi'><input onclick='HoraClickReturn();' type='text' name='hora' value='" + horaSelected + "' readonly=''  class='btn btn-primary w-100 box-shadow-0 font-weight-light text-uppercase text-white margin-top-10'/> </li>");

		//Dato info para proceso back
		var routeItineraryId = $(DomObj).attr("val");
		//alert(routeItineraryId);
		$("input[name='routeItineraryId']").val(routeItineraryId);
		var routeId = $("input[name='routeId']").val();
		//alert(routeId+" "+routeItineraryId);

		//Revisar Tipo de Ruta: Regular o D2D
		var tempTipoVal = $("input[name='routeTypeId']").val();
		if (tempTipoVal == '4') {
			//Si es regular, va a: parada (ver en: getStops())
			$(".parada").show();
		}
		else {
			//Si es D2D, va a: paradaGps (ver en: getStops())
			$(".gMapsIcon").hide();
			$(".parada").show();
		}

		getStops(ix, routeId, routeItineraryId);

		//habilitarRetroceso();

	} catch (err) {
		//alert("Error:"+err.message);
		send_debug("HoraClick", err.message);
	}
} /* ef */
function HoraClickReturn() {
	try {
		//alert('hora return');
		$(".hora").show();
		$(".tipoRuta,.sentido,.ruta,.parada,.dias,.confirmar,.gMapsIcon,#mapaParadas,.btnsMapPards").hide();

		$(".horaLi,.paradaLi,.diasLi").remove();
		$(".seat-row").remove();

		var routeId = $("input[name='routeId']").val();

		$("input[name='routeItineraryId']").val(0);
		$("input[name='stopId']").val(0);
		$("input[name='dias']").val(0);

		//alert("ojo:"+routeId);
		getHours(ix, routeId);

	} catch (err) {
		//alert("Error:"+err.message);
		send_debug("HoraClickReturn", err.message);
	}
} /* ef */


function ParadaClick(DomObj) {
	try {
		//alert("Parada. Ej: Entrada Principal del Pali Pacifico");
		$(".parada,.gMapsIcon").hide();
		$(".dias").show();

		//Dato info visible al usuario
		var paradaSelected = $(DomObj).text();
		//alert(paradaSelected);
		$(".selectedOptions>ul").append("<li class='paradaLi'><input onclick='ParadaClickReturn();' type='text' name='parada' value='" + paradaSelected + "' readonly=''  class='btn btn-primary w-100 box-shadow-0 font-weight-light text-uppercase text-white margin-top-10'/> </li>");

		//Dato info para proceso back
		var stopId = $(DomObj).attr("val");
		$("input[name='stopId']").val(stopId);

		//get_dates();
		//	habilitarRetroceso();
		var routeId = $("input[name='routeId']").val();
		var routeItineraryId = $("input[name='routeItineraryId']").val();
		getDias(ix, routeId, routeItineraryId);

	} catch (err) {
		//alert("Error:"+err.message);
		send_debug("ParadaClick", err.message);
	}
} /* ef */
function ParadaClickReturn() {
	try {
		//	alert('parada return');
		$(".parada").show();
		$(".tipoRuta,.sentido,.ruta,.hora,.dias,.confirmar,#mapaParadas,.btnsMapPards").hide();

		$(".paradaLi,.diasLi").remove();

		$(".seat-row").remove();

		$("input[name='stopId']").val(0);
		$("input[name='dias']").val(0);


		//Revisar Tipo de Ruta: Regular o D2D
		var tempTipoVal = $("input[name='routeTypeId']").val();
		if (tempTipoVal == '4') {
			//Ruta Regular
			$(".gMapsIcon").show();
		}
		else {
			//D2D
			$(".gMapsIcon").hide();
		}

	} catch (err) {
		//alert("Error:"+err.message);
		send_debug("ParadaClickReturn", err.message);
	}
} /* ef */


function DiaClickReturn() {
	try {

		//alert('dia return');
		$(".dias").show();
		$(".tipoRuta,.sentido,.ruta,.hora,.parada,.confirmar").hide();


		$("input[name='dias']").val(0);


		$(".diasLi").remove();
		$(".seat-row").remove();
		marcarLosDiasReales();


	} catch (err) {
		//alert("Error:"+err.message);
		send_debug("DiaClickReturn", err.message);
	}
} /* ef */


function ReservarBtnClick(DomObj) {
	try {
		//Array de checks seleccionados
		var seleccionadosTxt = new Array();
		var seleccionadosSeats = new Array();

		var abueloDias = $(DomObj).parents("ul");
		//Para cada seleccionado
		abueloDias.children("div").children("div").children(".ui-btn").children("div").children("input:checked").each(function () {
		//abueloDias.children("div").children("div").children(".ui-btn").children("label").children("input:checked").each(function () {
			//Texto
			var padreInput = $(this).parent("div");
			//	var txtDia = padreInput.children("label").children("b").text();
			var txtDia = padreInput.children("input").val();
			//	alert(txtDia);

			var txtSeat = $("#label" + txtDia).text();

			//Agrega el texto de los seleccionados a un array
			seleccionadosSeats.push(txtSeat);
			seleccionadosTxt.push(txtDia);
		});

		//Validar boton de: RESERVAR
		if (seleccionadosTxt.length <= 0 || seleccionadosSeats.length <= 0 || seleccionadosTxt.length != seleccionadosSeats.length) {
			//alert("Seleccione al menos 1 día");

			if (lg == 'en') {
				var txt1 = 'Attention';
				var txt2 = 'Select at least 1 day.';
			} else {
				var txt1 = 'Atención';
				var txt2 = 'Seleccione al menos 1 día.';
			}
			wp_alerta(txt1, txt2);
		}
		else {
			//alert("Días. Ej: Lunes 25 enero");
			$(".dias").hide();
			$(".confirmar").show();

			if (lg == 'en') {
				var txt1 = 'Reserved days';
			} else {
				var txt1 = 'Días reservados';
			}

			//Dato info visible al usuario
			//alert(seleccionadosTxt);
			$(".selectedOptions>ul").append("<li class='diasLi' onclick='DiaClickReturn();'>" + txt1 + ": " + seleccionadosTxt.length + "</li>");

			//Dato info para proceso back
			$("input[name='dias']").val(seleccionadosTxt);
			$("input[name='seats']").val(seleccionadosSeats);
		}
	} catch (err) {
		//alert("Error:"+err.message);
		send_debug("ReservarBtnClick", err.message);
	}
} /* ef */


function ConfirmarBtnClick() {
	try {
		//Datos Form
		var tipoRutaVal = parseInt($("input[name='routeTypeId']").val());
		var sentidoVal = parseInt($("input[name='routeWayId']").val());
		var rutaVal = parseInt($("input[name='routeId']").val());
		var horaVal = parseInt($("input[name='routeItineraryId']").val());
		var paradaVal = parseInt($("input[name='stopId']").val());
		var diasVal = $("input[name='dias']").val();
		var seatsVal = $("input[name='seats']").val();

		if (lg == 'en') {
			var txt = 'Attention';
			var txt1 = 'Route type still needs to be defined.';
			var txt2 = 'Route way still needs to be defined.';
			var txt3 = 'The route still needs to be defined.';
			var txt4 = 'Time still needs to be defined.';
			var txt5 = 'The stop still needs to be defined.';
			var txt6 = 'Days still needs to be defined.';
			var txt7 = 'Seats still needs to be defined.';
		} else {
			var txt = 'Atención';
			var txt1 = 'Falta definir el tipo de ruta.';
			var txt2 = 'Falta definir el sentido.';
			var txt3 = 'Falta definir la ruta.';
			var txt4 = 'Falta definir la hora.';
			var txt5 = 'Falta definir la parada.';
			var txt6 = 'Falta definir los días.';
			var txt7 = 'Falta definir los asientos.';
		}

		if (tipoRutaVal == 0 || tipoRutaVal == NaN) {
			wp_alerta(txt1, txt1);
			return;
		}

		if (sentidoVal == 0) {
			wp_alerta(txt, txt2);
			return;
		}

		if (rutaVal == 0) {
			wp_alerta(txt, txt3);
			return;
		}

		if (horaVal == 0) {
			wp_alerta(txt, txt4);
			return;
		}

		if (paradaVal == 0) {
			wp_alerta(txt, txt5);
			return;
		}

		if (diasVal == 0) {
			wp_alerta(txt, txt6);
			return;
		}

		if (seatsVal == 0) {
			wp_alerta(txt, txt7);
			return;
		}

		initAjax();
		var requestData = { cmd: "realizarReservacion", uuid: ix, routeTypeId: tipoRutaVal, routeWayId: sentidoVal, routeId: rutaVal, routeItineraryId: horaVal, stopId: paradaVal, dias: diasVal, seats: seatsVal };

		$.ajax({ data: requestData })
			.done(function (dataReturn) { process_result_realizarReservacion(dataReturn) })
			.fail(function () { });

	} catch (err) {
		//alert("Error:"+err.message);
		send_debug("ConfirmarBtnClick", err.message);
	}
}


//Controlar Tipo de Ruta: Regular o D2D
/*$(".regularOpt").on("click", function(){
	$("input[name='routeTypeId']").val("4");
});
$(".d2dOpt").on("click", function(){
	$("input[name='routeTypeId']").val("5");
});*/


//Marcar los checks reales (según los visuales: naranjas)
function marcarLosDiasReales() {
	//Revisar si; el checkbox falso naranja está marcado, para marcar el checkbox real
	if ($("li.ui-btn>div>label").hasClass("ui-checkbox-on") == true) {
		$("li.ui-btn>div>label.ui-checkbox-on").next().prop('checked', true);
	}
}


function process_result_realizarReservacion(dataReturn) {
	try {
		//alert(dataReturn);
		var obj = JSON.parse(dataReturn);

		//Envío de Datos
		/*...*/
		//Respuesta
		//alert("Reservación realizada con éxito.");
		//var respuesta = "1";
		//alert();
		if (lg == 'en') {
			var txt1 = 'Reservation made successfully';
			var txt2 = 'New reservation';
			var txt3 = 'Go to main page';
			var txt4 = 'The reservation could not be made.';
			var txt5 = 'Try again';
			var txt6 = 'One or more seats were reassigned';
		} else {
			var txt1 = 'Reservación realizada con éxito.';
			var txt2 = 'Nueva Reservación';
			var txt3 = 'Ir al inicio';
			var txt4 = 'No se pudo realizar la reservación.';
			var txt5 = 'Intentar otra vez';
			var txt6 = 'Uno o más asientos fueron reasignados';
		}
		if (obj.resultado == '1' || obj.info2.resultado == '1') {

			$(".respuesta").html('<li class="msg success ui-li-static ui-body-inherit ui-first-child alert alert-success">' +
				txt1 +
				'</li><li id="reassigned" class="msg success ui-li-static ui-body-inherit ui-first-child" style="background-color: #FF9800!important;display:none;margin:5px 0px">' + txt6 + '</li>' +
				'<li class="ui-li-static ui-body-inherit">' +
				'<button type="button" onclick="javascript:location.href=\'' + lg + '_reservacion.html?se=' + ix + '\'" class="tipoRutaOpt ui-btn-raised clr-primary waves-effect waves-button ui-btn waves-effect waves-button waves-effect waves-button btn btn-primary w-100 box-shadow-0 font-weight-light text-uppercase margin-top-10 text-white">' + txt2 + '</button>' +
				'</li>' +
				'<li class="ui-li-static ui-body-inherit ui-last-child">' +
				'<button type="button"  onclick="javascript:location.href=\'' + lg + '_main.html?se=' + ix + '\'"class="tipoRutaOpt ui-btn-raised waves-effect waves-button ui-btn waves-effect waves-button waves-effect waves-button btn btn-primary w-100 box-shadow-0 font-weight-light text-uppercase margin-top-10 text-white">' + txt3 + '</button>' +
				'</li>');

			// Resultado del asiento que se asigno
			if (obj.reassigned != undefined && obj.reassigned == 1) {
				$("#reassigned").show();
			}
			//

		} else {
			$(".respuesta").html('<li class="msg error ui-li-static ui-body-inherit ui-first-child">' +
				txt4 +
				'</li>' +
				/*'<li class="ui-li-static ui-body-inherit">'+
					'<button type="button" onclick="ConfirmarBtnClick()" class="confirmarBtn ui-btn-raised clr-primary waves-effect waves-button ui-btn waves-effect waves-button waves-effect waves-button">'+txt5+'</button>'+
				'</li>'+*/
				'<li class="ui-li-static ui-body-inherit">' +
				'<button type="button" onclick="javascript:location.href=\'' + lg + '_reservacion.html?se=' + ix + '\'" class="tipoRutaOpt ui-btn-raised clr-primary waves-effect waves-button ui-btn waves-effect waves-button waves-effect waves-button">' + txt2 + '</button>' +
				'</li>' +
				'<li class="ui-li-static ui-body-inherit ui-last-child">' +
				'<button type="button"  onclick="javascript:location.href=\'' + lg + '_main.html?se=' + ix + '\'"class="tipoRutaOpt ui-btn-raised waves-effect waves-button ui-btn waves-effect waves-button waves-effect waves-button">' + txt3 + '</button>' +
				'</li>');
		}

		//Ef
		$(".confirmar").hide();
		$(".respuesta").show();

		$(".selectedOptions").hide();
		$(".formReservations hr").hide();

	} catch (err) {
		//alert("Error:"+err.message);
		send_debug("process_result_realizarReservacion", err.message);
	}
}