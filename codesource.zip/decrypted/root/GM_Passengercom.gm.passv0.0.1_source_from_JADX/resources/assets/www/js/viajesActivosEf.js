$(document).ready(function () {
	$('.sentido,.viajesResult,.selectedOptions,.ruta,.viajes').hide();
});

function SiteClickReturn(DomObj) {
	try {

		$(".selectedOptions>ul>li").remove();
		$(".recuadro.selectedOptions,#mapaParadas,.btnsMapPards").hide();
		$(".tipoRuta").show();

		// $(".sentido,.ruta,.hora,.parada,.dias,.confirmar,.gMapsIcon,#horaLimite").hide();
		// $(".tipoLi,.sentidoLi,.rutaLi,.horaLi,.paradaLi,.diasLi").remove();

		// $("input[name='routeTypeId']").val(0);
		// $("input[name='routeWayId']").val(0);
		// $("input[name='routeId']").val(0);

		/////
		$(".sentido,.ruta,.viajes").hide();
		$(".tipoLi,.sentidoLi,.rutaLi").remove();

		$("input[name='routeTypeId']").val(0);
		$("input[name='routeWayId']").val(0);
		$("input[name='routeId']").val(0);
		/////

		$("#regularOpt").css("display", "none");
		$("#d2d-opt").css("display", "none");
		$("#taxi-opt").css("display", "none");

		$("#temp1").show();
		loadpage(ix);

	} catch (err) {
		//alert("Error:"+err.message);
		send_debug("SiteClickReturn", err.message);
	}
} /* ef */

function SiteClick(DomObj) {
	try {

		//Dato info para proceso back
		var siteId = $(DomObj).attr("val");
		$("input[name='siteId']").val(siteId);
		$("#titulo").html("Tipo");
		$(".SiteOpt").css("display", "none");
		//$("#temp1").show();

		mostrar_botones();

		var SiteSelected = $(DomObj).text();
		//alert(tipoRutaSelected);
		$(".selectedOptions>ul").append("<li class='tipoLi status-container'><input onclick='SiteClickReturn()' type='text' name='tipoRuta' value='" + SiteSelected + "' readonly='' /> </li>");


	} catch (err) {
		//alert("Error:"+err.message);
		send_debug("SiteClick", err.message);
	}
} /* ef */

function mostrar_botones() {
	var actual_option_def = get_ls("ls_opt");
	procesar_option_def(actual_option_def);
	//alert(actual_option_def);

	var s = actual_option_def.search("SRR");
	var d = actual_option_def.search("SD2D");

	if (s >= 0) { $("#regularOpt").show(); } else { $("#regularOpt").hide(); }
	if (d >= 0) { $("#d2d-opt").show(); } else { $("#d2d-opt").hide(); }
	$("#temp1").hide();
}

function tipoRutaClick(DomObj) {
	try {
		$(".tipoRuta").hide();
		$(".recuadro.selectedOptions").show();
		$(".sentido").show();

		$(".formReservations hr").show();
		$(".selectedOptions").show();

		//Dato info visible al usuario
		var tipoRutaSelected = $(DomObj).text();
		//alert(tipoRutaSelected);
		$(".selectedOptions>ul").append("<li class='tipoLi status-container' onclick='tipoRutaClickReturn()'>" + tipoRutaSelected + "</li>");

		//Dato info para proceso back
		var routeTypeId = $(DomObj).attr("val");
		$("input[name='routeTypeId']").val(routeTypeId);

	} catch (err) {
		//alert("Error:"+err.message);
		send_debug("tipoRutaClick", err.message);
	}
} /* ef */
function tipoRutaClickReturn() {
	try {
		// $(".selectedOptions>ul>li").remove();
		// $(".recuadro.selectedOptions").hide();
		$(".tipoRuta").show();

		$(".sentido,.ruta,.viajes").hide();
		$(".tipoLi,.sentidoLi,.rutaLi").remove();

		$("input[name='routeTypeId']").val(0);
		$("input[name='routeWayId']").val(0);
		$("input[name='routeId']").val(0);

	} catch (err) {
		//alert("Error:"+err.message);
		send_debug("tipoRutaClickReturn", err.message);
	}
} /* ef */

function SentidoClick(DomObj) {
	try {
		$(".sentido").hide();
		$(".ruta,.selectedOptions").show();
		//alert('sentido go');
		//Dato info visible al usuario
		var sentidoSelected = $(DomObj).text();
		var tipox = $("input[name='routeTypeId']").val();

		var SiteId_Actual = $("input[name='siteId']").val();

		$(".selectedOptions>ul").append("<li class='sentidoLi status-container' onclick='SentidoClickReturn()'>" + sentidoSelected + "</li>");

		//Dato info para proceso back
		var routeWayId = $(DomObj).attr("val");
		$("input[name='routeWayId']").val(routeWayId);

		//alert(tipox);
		//alert(routeWayId);
		getRoutes(ix, routeWayId, tipox, SiteId_Actual);
		//habilitarRetroceso();
	} catch (err) {
		//alert("Error:"+err.message);
		send_debug("SentidoClick", err.message);
	}
} /* ef */
function SentidoClickReturn() {
	try {
		//alert('sentido return');
		$(".sentido").show();
		$(".ruta,.viajes").hide();

		$(".sentidoLi,.rutaLi").remove();

		$("input[name='routeWayId']").val(0);
		$("input[name='routeId']").val(0);

	} catch (err) {
		//alert("Error:"+err.message);
		send_debug("SentidoClickReturn", err.message);
	}
} /* ef */


function RutaClick(DomObj) {
	try {
		//alert('ruta go ');
		//alert("Ruta. Ej: Alajuela - Heredia");
		$(".ruta").hide();
		$(".viajes").show();

		//Dato info visible al usuario
		var rutaSelected = $(DomObj).text();
		//alert("ojo:"+rutaSelected);
		$(".selectedOptions>ul").append("<li class='rutaLi status-container' onclick='RutaClickReturn();'>" + rutaSelected + "</li>");

		//Dato info para proceso back
		var routeId = $(DomObj).attr("val");
		$("input[name='routeId']").val(routeId);

		//alert("ojo:"+routeId);
		getViajes(ix, routeId);
		//getHours(ix,routeId);

		//habilitarRetroceso();
	} catch (err) {
		//alert("Error:"+err.message);
		send_debug("RutaClick", err.message);
	}
} /* ef */
function RutaClickReturn() {
	try {
		//alert('ruta return');
		$(".sentido,.viajes").hide();
		$(".ruta").show();
		$(".ruta").css('display', 'block');

		$(".rutaLi").remove();

		$('.rutashoy').html();

		var tipox = $("input[name='routeTypeId']").val();
		var routeWayId = $("input[name='routeWayId']").val();

		$("input[name='routeId']").val(0);

		getRoutes(ix, routeWayId, tipox);
	} catch (err) {
		//alert("Error:"+err.message);
		send_debug("RutaClickReturn", err.message);
	}
} /* ef */

